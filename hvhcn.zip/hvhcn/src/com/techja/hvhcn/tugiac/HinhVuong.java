package com.techja.hvhcn.tugiac;

import com.techja.hvhcn.dinh.Dinh;

public class HinhVuong extends TuGiac {
	private double dDC;

	public void tinhDoDaiCanh(Dinh d1, Dinh d2) {
		double x1 = d1.getX();
		double x2 = d2.getX();
		double y1 = d1.getY();
		double y2 = d2.getY();
		dDC = Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
	}

	@Override
	public double tinhChuVi() {
		chuVi = 4 * dDC;
		return this.chuVi;
	}

	@Override
	public double tinhDienTich() {
		dienTich = Math.pow(dDC, 2);
		return dienTich;
	}

	@Override
	public void inTT() {
		super.inTT();
		System.out.println("Do dai canh la" + dDC + "\nChu Vi La" + chuVi + "\nDien Tich La:" + dienTich);
	}

}
