package com.plus17.ucln.main;

import com.plus17.ucnl.ucln.UCLN;

public class Main {

	public static void main(String[] args) {
		UCLN uCLN = new UCLN(6,12);
		uCLN.timUocLonNhat();
	}

}
