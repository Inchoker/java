package com.plus17.smartfinder.main;

import com.plus17.smartfinder.smartfinder.SmartFinder;

public class Main {

	public static void main(String[] args) {
		SmartFinder sF= new SmartFinder(40);
		sF.findLargeArea();

	}

}
